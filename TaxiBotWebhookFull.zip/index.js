require("dotenv").config();
const express = require("express");
const axios = require("axios");
const { WebhookClient } = require("dialogflow-fulfillment");

const app = express();
app.use(express.json());

const MONTEVIDEO_LIMITS = ["Montevideo", "MONTEVIDEO"];

async function calcularTarifa(origen, destino, fechaHora) {
  const mapsKey = process.env.GOOGLE_MAPS_API_KEY;

  const url = \`https://maps.googleapis.com/maps/api/directions/json?origin=\${encodeURIComponent(origen)}&destination=\${encodeURIComponent(destino)}&departure_time=\${Math.floor(fechaHora.getTime() / 1000)}&traffic_model=best_guess&key=\${mapsKey}\`;

  const response = await axios.get(url);
  const route = response.data.routes[0];
  const leg = route.legs[0];
  const distanciaMetros = leg.distance.value;
  const tiempoSegundos = leg.duration_in_traffic.value;

  const km = distanciaMetros / 1000;
  const fichasPorDistancia = distanciaMetros / 100; // una ficha cada 100 metros
  const fichasPorTiempo = tiempoSegundos / 18; // una ficha cada 18 segundos detenido

  let totalFichas = Math.ceil(fichasPorDistancia + fichasPorTiempo);
  let tarifa = 62.98 + (totalFichas * 3.66); // bajada de bandera + fichas

  // Verificar si aplica tarifa nocturna
  const hora = fechaHora.getHours();
  const dia = fechaHora.getDay(); // 0=domingo
  const esNocturno = hora >= 22 || hora < 6 || dia === 0;

  if (esNocturno) {
    tarifa *= 1.2;
  }

  // Verificar si destino está fuera de Montevideo
  const destinoCiudad = leg.end_address;
  const fueraDeMontevideo = !MONTEVIDEO_LIMITS.some(ciudad => destinoCiudad.includes(ciudad));

  if (fueraDeMontevideo) {
    tarifa *= 1.65;
  }

  return tarifa.toFixed(2);
}

async function consultarGPT(mensaje) {
  const apiKey = process.env.OPENAI_API_KEY;
  const response = await axios.post(
    "https://api.openai.com/v1/chat/completions",
    {
      model: "gpt-4",
      messages: [{ role: "user", content: mensaje }],
      temperature: 0.7
    },
    {
      headers: {
        Authorization: \`Bearer \${apiKey}\`,
        "Content-Type": "application/json"
      }
    }
  );
  return response.data.choices[0].message.content;
}

app.post("/webhook", async (req, res) => {
  const agent = new WebhookClient({ request: req, response: res });

  async function cotizarViaje(agent) {
    const origen = agent.parameters.origin;
    const destino = agent.parameters.destination;
    const fecha = agent.parameters.date;
    const hora = agent.parameters.time;

    if (!origen || !destino || !fecha || !hora) {
      agent.add("Por favor indicame origen, destino, fecha y hora para cotizar tu viaje.");
      return;
    }

    const fechaHora = new Date(\`\${fecha}T\${hora}\`);
    try {
      const precio = await calcularTarifa(origen, destino, fechaHora);
      agent.add(\`El costo estimado del viaje es de \$\${precio}.\`);
    } catch (err) {
      console.error("Error al calcular tarifa:", err.message);
      agent.add("Lo siento, hubo un error al calcular la tarifa. ¿Podés repetir los datos?");
    }
  }

  async function fallback(agent) {
    const pregunta = agent.query;
    const respuesta = await consultarGPT(pregunta);
    agent.add(respuesta);
  }

  let intentMap = new Map();
  intentMap.set("Cotizar Viaje", cotizarViaje);
  intentMap.set("Default Fallback Intent", fallback);
  agent.handleRequest(intentMap);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(\`TaxiBot webhook está corriendo en el puerto \${PORT}\`);
});
