# TaxiBot Webhook (GPT + Google Maps)

Este es el webhook de TaxiBot con integración completa a:

- ✅ ChatGPT (GPT-4) para fallback
- ✅ Google Maps API para calcular la tarifa de un viaje

## ¿Qué hace?

- Escucha las solicitudes desde Dialogflow
- Si el intent es "Cotizar Viaje", calcula el precio usando Maps + lógica real de fichas
- Si no entiende la intención, responde con ChatGPT

## ¿Cómo usar?

1. Subí este proyecto a GitHub
2. En Glitch: "Import from GitHub"
3. En `.env`, cargá tus claves API:
```
OPENAI_API_KEY=sk-...
GOOGLE_MAPS_API_KEY=AIza...
```
4. En Dialogflow → Fulfillment → activá webhook y poné:
```
https://tuprojecto.glitch.me/webhook
```

---
